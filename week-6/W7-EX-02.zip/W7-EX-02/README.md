# Chạy dự án

- Sử dụng câu lệnh để cài thư viện cần thiết: npm i
- Sử dụng câu lệnh để chạy dự án: npm run dev
